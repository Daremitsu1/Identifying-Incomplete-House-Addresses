Data collected around 2020-05-27 by OpenAddresses (http://openaddresses.io).

Address data is essential infrastructure. Street names, house numbers and
postal codes, when combined with geographic coordinates, are the hub that
connects digital to physical places.

Data licenses can be found in LICENSE.txt.

Data source information can be found at
https://github.com/openaddresses/openaddresses/tree/e54e839262293a856d75f7cfbf5f727e510db1de/sources
